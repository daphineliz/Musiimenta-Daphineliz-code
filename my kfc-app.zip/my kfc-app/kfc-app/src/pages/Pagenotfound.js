import React from 'react'
import Layout from '../components/Layout/Layout'

const pagenotfound = () => {
  return (
    <Layout>
        <h1>Page not found</h1>
    </Layout>
  )
}

export default pagenotfound